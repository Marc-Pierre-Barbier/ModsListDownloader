java -jar ModPackDl.jar -t -v
